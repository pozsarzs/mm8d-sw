Module pyModbusTCP.client
=========================

.. automodule:: pyModbusTCP.client

*This module provide the ModbusClient class used to deal with modbus server.*

class pyModbusTCP.client.ModbusClient
-------------------------------------

.. autoclass:: ModbusClient
   :members:
   :special-members:

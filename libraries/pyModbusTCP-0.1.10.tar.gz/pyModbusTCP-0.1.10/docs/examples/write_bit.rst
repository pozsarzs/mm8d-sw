=========================
Simple write bits example
=========================


.. literalinclude:: ../../examples/write_bit.py

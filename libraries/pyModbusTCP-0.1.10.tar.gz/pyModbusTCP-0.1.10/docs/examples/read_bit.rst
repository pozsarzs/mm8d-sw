========================
Simple read bits example
========================


.. literalinclude:: ../../examples/read_bit.py

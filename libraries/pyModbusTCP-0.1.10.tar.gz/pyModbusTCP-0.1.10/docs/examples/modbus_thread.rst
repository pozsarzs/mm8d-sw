=======================================
An example with a modbus polling thread
=======================================


.. literalinclude:: ../../examples/modbus_thread.py

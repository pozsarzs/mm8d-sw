==============================
Simple blocking server example
==============================


.. literalinclude:: ../../examples/server.py

================================
An example for add float support
================================


.. literalinclude:: ../../examples/float_support.py

==================================================
Server example with alive word and downtime period
==================================================


.. literalinclude:: ../../examples/server_with_schedule.py

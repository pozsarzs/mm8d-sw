=============================
Simple read registers example
=============================


.. literalinclude:: ../../examples/read_register.py

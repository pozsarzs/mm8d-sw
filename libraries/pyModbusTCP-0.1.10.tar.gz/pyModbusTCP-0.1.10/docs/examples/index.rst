pyModbusTCP examples
====================

*Here some examples to see pyModbusTCP in some usages cases*

.. toctree::
   :maxdepth: 2

   float_support
   read_register
   read_bit
   write_bit
   modbus_thread
   server
   server_with_schedule

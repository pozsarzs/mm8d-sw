==============================
Client: read holding registers
==============================


.. literalinclude:: ../../examples/client_read_h_registers.py

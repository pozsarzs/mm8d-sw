======================
Client: polling thread
======================


.. literalinclude:: ../../examples/client_thread.py

===================
Server: basic usage
===================


.. literalinclude:: ../../examples/server.py

===============================
Client: add float (inheritance)
===============================


.. literalinclude:: ../../examples/client_float.py

=================================
Server: Modbus/TCP serial gateway
=================================


.. literalinclude:: ../../examples/server_serial_gw.py

==========================
Server: with an allow list
==========================


.. literalinclude:: ../../examples/server_allow.py

Module pyModbusTCP.client
=========================

.. automodule:: pyModbusTCP.client

*This module provide the ModbusClient class used to deal with modbus server.*

class ModbusClient
------------------

.. autoclass:: ModbusClient
   :members:
   :special-members: __init__

class DeviceIdentificationResponse
----------------------------------

.. autoclass:: DeviceIdentificationResponse
   :members:
   :special-members: __init__
.. include:: ../../AUTHORS.rst

Constants
=========

.. automodule:: pymodbus.constants
    :members:
    :undoc-members:
    :show-inheritance:
    :noindex:

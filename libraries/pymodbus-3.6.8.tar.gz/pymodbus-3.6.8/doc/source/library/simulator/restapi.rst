Pymodbus simulator ReST API
===========================

TO BE DOCUMENTED.

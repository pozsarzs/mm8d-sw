Simulator datastore
===================

The simulator datastore is an advanced datastore.
The simulator allows to simulate the registers of a real life modbus device by adding a simple dict (definition see :ref:`Device entries`).

The simulator datastore allows to add actions (functions) to a register, and thus allows a low level automation.

Documentation :class:`pymodbus.datastore.ModbusSimulatorContext`

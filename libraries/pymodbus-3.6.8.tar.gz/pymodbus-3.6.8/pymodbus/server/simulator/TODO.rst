- Add parameter min/max to action_random
- Add action_random do not change with every read (--randomize from repl)
- Add change_rate to getValues (--change_rate from repl)

- Code for register setValue (Uint32....)
- Code for calls
- Format tracer/responder (hex, function name etc.)
- Code for call tracer
- Code for response tracer
- Code for response simulator
- Code for logs
- Code for server

- Code for JSON register
- Code for JSON logs
- Code for JSON Calls
- Code for JSON server

- Document simulator general
- Document JSON.

- Update datastore simulator example

- Add test of server simulator (100% coverage)

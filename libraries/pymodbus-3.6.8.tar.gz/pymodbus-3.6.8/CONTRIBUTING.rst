Just fork the repo and raise your PR against `dev` branch.

We always have more work than time, so feel free to open a discussion / issue on a theme you want to solve.

For instructions please refer to README.rst, which details how to install a development environment etc.

"""Available examples."""

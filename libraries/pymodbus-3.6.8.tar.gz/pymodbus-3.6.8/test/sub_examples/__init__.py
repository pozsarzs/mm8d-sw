"""Test of examples."""

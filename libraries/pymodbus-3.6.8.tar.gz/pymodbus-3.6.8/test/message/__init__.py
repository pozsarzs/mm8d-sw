"""Test of message layer."""
